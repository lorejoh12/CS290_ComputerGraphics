Sound sources:
http://www.freesound.org/people/Corsica_S/sounds/72866/
http://www.freesound.org/people/alphahog/sounds/47345/
http://www.freesound.org/people/TwistedLemon/sounds/17643/
http://www.freesound.org/people/Corsica_S/sounds/82986/
http://www.freesound.org/people/jppi_Stu/sounds/70986/
