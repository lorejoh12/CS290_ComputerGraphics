# GLEAT
Geometry Library for Evolutionary Anthropology and Teaching

By Tingran Gao and Chris Tralie
