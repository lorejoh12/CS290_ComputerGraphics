precision mediump float;
varying vec4 fColor;
void main(void) {
    gl_FragColor = fColor;
}
